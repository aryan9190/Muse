//
//  museApp.swift
//  muse
//
//  Created by Victoria De Alba on 10/13/23.
//

import SwiftUI

@main
struct museApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
